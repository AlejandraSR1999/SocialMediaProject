import { DataSource } from 'typeorm';

export const connectionSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_URL || 'localhost',
  port: 5432,
  username: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || 'socialapp2023',
  database: process.env.DB_NAME || 'socialapp',
  logging: true,
  synchronize: true,
  entities: ['src/persistence/*.entity{.ts,.js}'],
  migrations: ['src/migrations/*{.ts,.js}'],
});