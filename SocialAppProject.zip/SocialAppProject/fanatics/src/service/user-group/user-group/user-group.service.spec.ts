import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataBasesEnum } from '../../../enums/data-bases.enum';
import { UserGroupEntity } from '../../../persistence/user-group.entity';
import { Repository } from 'typeorm';
import { UserGroupService } from './user-group.service';

describe('UserGroupService', () => {
  let service: UserGroupService;
  let userGroupRepository: Repository<UserGroupEntity>;
  const USER_GROUP_REPOSITORY_TOKEN = getRepositoryToken(
    UserGroupEntity, DataBasesEnum.POSTGRES
  );

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UserGroupService,
        {
          provide: USER_GROUP_REPOSITORY_TOKEN,
          useValue: {}
        }
      ],
    }).compile();

    service = module.get<UserGroupService>(UserGroupService);
    userGroupRepository = module.get<Repository<UserGroupEntity>>(
      USER_GROUP_REPOSITORY_TOKEN
    );
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
