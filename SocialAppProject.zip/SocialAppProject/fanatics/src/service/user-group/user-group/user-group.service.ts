import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserGroupDto } from '../../../dto/user-group.dto';
import { DataBasesEnum } from '../../../enums/data-bases.enum';
import { GroupEntity } from '../../../persistence/group.entity';
import { UserGroupEntity } from '../../../persistence/user-group.entity';
import { Repository } from 'typeorm';

@Injectable()
export class UserGroupService {
    constructor(
        @InjectRepository(UserGroupEntity, DataBasesEnum.POSTGRES)
        private readonly userGroupRepository: Repository<UserGroupEntity>
    ){}

    findAll() {
        return this.userGroupRepository.find();
    }

    create(userId: string, GroupEntity: GroupEntity){
        const newUserGroup = new UserGroupEntity();
        newUserGroup.user_ = userId;
        newUserGroup.group_ = GroupEntity.id;
        return this.userGroupRepository.save(newUserGroup);
    }

    async update(userGroupId: string, userGroupDto: UserGroupDto){
        const updateUserGroup = await this.userGroupRepository.preload({
            id: userGroupId,
            ...userGroupDto
        })
        if(!updateUserGroup){
            return 'The user_group value doesn\'t exist';
        }
        return await this.userGroupRepository.save(updateUserGroup);
    }

    delete(userGroupId: string){
        const foundUserGroup = this.userGroupRepository.findOneBy({id: userGroupId});
        if(!foundUserGroup){
            return 'The user_group value doesn\'t exist';
        }
        const deleteUserGroup = this.userGroupRepository.delete(userGroupId);
        if(!deleteUserGroup){
            return 'The user_group value was deleted successfully';
        }
    }
}
