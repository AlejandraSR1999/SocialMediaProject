import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { UserEntity } from '../../persistence/user.entity';
import { FindOneOptions, Repository } from 'typeorm';
import { InterestEntity } from '../../persistence/interest.entity';
import { InterestService } from './interest.service';

describe('InterestService', () => {
  let service: InterestService;
  let interestRepository: Repository<InterestEntity>;
  const INTEREST_REPOSITORY_TOKEN = getRepositoryToken(InterestEntity);
  
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [{
         provide: INTEREST_REPOSITORY_TOKEN,
         useValue: {
          create: jest.fn(),
          save: jest.fn(),
          update: jest.fn(),
          preload: jest.fn(),
          delete: jest.fn(),
          findOneBy: jest.fn(),
          findOne: jest.fn()
         }
      }]
    }).compile();
    
    service = new InterestService(interestRepository);
    interestRepository = module.get<Repository<InterestEntity>>(INTEREST_REPOSITORY_TOKEN);

  });


  it('Service should be defined', () => {
    expect(service).toBeDefined();
  });

  it('InterestRepository should be defined', async () => {
    expect(interestRepository).toBeDefined();
  });

  it('It should create a new interes', async () => {
    jest.spyOn(interestRepository, 'create').mockReturnValue(
      {
        id_interest:1,
        user_id: '8b10bbb7-9fd9-43e7-9f5c-b3cced412c44',
        interest: 'Boxeo',
        user: new UserEntity()
      }
    );

    expect(interestRepository.create({
      user_id: '8b10bbb7-9fd9-43e7-9f5c-b3cced412c44',
      interest: 'Boxeo'
    })).toEqual({
      id_interest:1,
      user_id: '8b10bbb7-9fd9-43e7-9f5c-b3cced412c44',
      interest: 'Boxeo',
      user: new UserEntity()
    });
  });

  it('It should create a new interest using DTO', async () => {
    const dto = new InterestEntity();
    expect(service.create(dto)).not.toEqual(null);
  });

  it('It should delete a interest', async () => {
    const deleteInterestSpy = jest.spyOn(interestRepository, 'delete');
    const interestId= 1;
    interestRepository.delete(interestId);
    expect(deleteInterestSpy).toHaveBeenCalledWith(interestId);

  });

  it('It should update a interest', async () => {
    const updateInterest = jest.spyOn(interestRepository, 'update');
    const interestId = 1;
    const dto = new InterestEntity();
    interestRepository.update(interestId, dto);
    expect(updateInterest).toHaveBeenCalledWith(interestId, dto);
  });

  it('It should findOne interest', async () => {
    const findOneInterest = jest.spyOn(interestRepository, 'findOne');
    const findOneOptions: FindOneOptions = {};
    interestRepository.findOne(findOneOptions);
    expect(findOneInterest).toHaveBeenCalledWith(findOneOptions);
  });
  
  
  
});
