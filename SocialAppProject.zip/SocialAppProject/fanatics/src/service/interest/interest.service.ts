import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { InterestEntity } from '../../persistence/interest.entity';
import { Repository } from 'typeorm';
import { DataBasesEnum } from '../../enums/data-bases.enum';
import { InterestDTO } from '../../dto/interest.dto';

@Injectable()
export class InterestService {
    constructor(
        @InjectRepository(InterestEntity, DataBasesEnum.POSTGRES)
        private readonly interestRepository: Repository<InterestEntity>
    ){}
     
    findAll() {
        return this.interestRepository.find();
    }

    create(InterestDTO: InterestDTO){
        const newGroup = this.interestRepository.create(InterestDTO);
        return this.interestRepository.save(newGroup);
    }

    findOne(interestId: number){
        return this.interestRepository.findOneBy({id_interest: interestId});
    }

    async update(interestId: number, UpdateUserDto: InterestDTO){
        const updatedInterest = await this.interestRepository.preload({
            id_interest: interestId,
            ...UpdateUserDto
        })
        if(!updatedInterest){
            return 'There is no interest with this characteristic';
        }
        return await this.interestRepository.save(updatedInterest);
    }

    delete(interestId: number){
        const interestFound = this.interestRepository.findOneBy({id_interest: interestId});
        if(!interestFound){
            return 'There is no interest with this characteristic';
        }
        const deleteUser = this.interestRepository.delete(interestId);
        if(!deleteUser){
            return 'The interest was deleted successfully';
        }
    }
}
