import { Test, TestingModule } from '@nestjs/testing';
import { UserService } from './user.service';
import { UserEntity } from '../../persistence/user.entity';
import { getRepositoryToken, TypeOrmModule } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserController } from '../../controller/user/user.controller';
import { DataBasesEnum } from '../../enums/data-bases.enum';
import { CreateUserDto } from '../../dto/create-user.dto';

describe('UserService', () => {
  let controller: UserController;
  let service: UserService;
  let userRepository: Repository<UserEntity>;
  const USER_REPOSITORY_TOKEN = getRepositoryToken(UserEntity,DataBasesEnum.POSTGRES);
  beforeEach(async () => {
     const module: TestingModule = await Test.createTestingModule({
       controllers: [UserController],
       providers: [{
        provide: UserService, 
        useValue:{
          create: jest.fn(),
          save: jest.fn(),
          findByNickname: jest.fn(),
          find: jest.fn(),
          delete: jest.fn(),
          findOneBy: jest.fn(),
          preload: jest.fn(),
          findByExactMatch: jest.fn(),
        }
       },
        { 
        provide: USER_REPOSITORY_TOKEN,
          useValue: {
            create: jest.fn(),
            save: jest.fn(),
            findByNickName: jest.fn(),
            find: jest.fn(),
            delete: jest.fn(),
            findOneBy: jest.fn(),
            preload: jest.fn(),
            findByExactMatch: jest.fn(),
            update: jest.fn()
          }
       }]
     }).compile();

    controller = module.get<UserController>(UserController);
    service = new UserService(userRepository);
    userRepository = module.get<Repository<UserEntity>>(USER_REPOSITORY_TOKEN);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should call userRepository.create with the correct params',async()=>{
    const date = new Date("1999-01-01");
    const createNewUser = jest.spyOn(service,'create');
    let newUser = new CreateUserDto();
    newUser = {firstName: 'Alejandra', lastName: 'Salazar', dateBirth: date, nickName: 'ale',password: 'ale123',email: 'alexxa@gmail.com'};
    service.create(newUser);
    expect(createNewUser).toHaveBeenCalledWith(newUser);

  });  

    it('should call userRepository.findByNickName with the correct params',async()=>{
      const findUserByNickName = jest.spyOn(service,'findByNickName');
      const nickName = 'ale';
      service.findByNickName(nickName);
      expect(findUserByNickName).toHaveBeenCalledWith(nickName);

    });  

    it('should call userRepository.delete with the correct id', async () => {
        const userId = '1';
        const deleteUser = jest.spyOn(service, 'delete');
        service.delete(userId);
        expect(deleteUser).toHaveBeenCalledWith(userId);
    });

    it('should call userRepository.update with the correct params', async () => {
      const updateUserSpy = jest.spyOn(service, 'update');
      const userId = '1';
      const updateUserDto = {
        firstName: 'Alejandra',
        lastName: 'Salazar',
        dateBirth: new Date("1999-01-01"),
        nickName: 'ale',
        password: 'ale123',
        email: 'alexxa@gmail.com'
      };
      service.update(userId, updateUserDto);
      expect(updateUserSpy).toHaveBeenCalledWith(userId, updateUserDto);
    });

    it('should call userRepository.findByExactMatch with the correct params', async () => {
      const findByExactMatch = jest.spyOn(service, 'findByExactMatch');
      const firstName = 'Alejandra';
      const lastName = 'Salazar';
      service.findByExactMatch(firstName, lastName);
      expect(findByExactMatch).toHaveBeenCalledWith(firstName, lastName);
    });  
});
      






 





