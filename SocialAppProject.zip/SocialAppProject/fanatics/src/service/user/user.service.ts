import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateUserDto } from '../../dto/create-user.dto';
import { CreateOauthUserDto } from '../../dto/create-oauth-user.dto';
import { DataBasesEnum } from '../../enums/data-bases.enum';
import { UserEntity } from '../../persistence/user.entity';
import { Repository, UpdateDateColumn } from 'typeorm';
import { UpdateUserDto } from '../../dto/update-user.dto';
import { IUserService } from '../../interfaces/IUserInterface.interface';
import * as fs from 'fs';
import { join } from 'path';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class UserService implements IUserService {

    constructor(
        @InjectRepository(UserEntity, DataBasesEnum.POSTGRES)
        private readonly userRepository: Repository<UserEntity>,
        private jwtService: JwtService
    ){}
     
    async findAll() {
        return await this.userRepository.findBy({status:true});
    }
    async findById(userId: string){
        const userLocated = await this.userRepository.findOneBy({id: userId, status:true});
        if(!userLocated){
            return 'There is not user with this characteristic';
        }
        return userLocated;
    }

    create(CreateUserDto: CreateUserDto, req: any){
        const dateRestriction = new Date('2005-01-01');
        const dateSetting = new Date(CreateUserDto.dateBirth);
        const imageUrl = `${req.protocol}://${req.get('host')}/img/${req.file.filename}`;
        if (dateSetting < dateRestriction) {
            const newUser = this.userRepository.create(CreateUserDto);
            const userWithImage = {...newUser, profileImage: imageUrl};
            return this.userRepository.save(userWithImage);
        }
        return 'You must be 18 or older';
    }


    async createOauthUser(createOauthUserDto: CreateOauthUserDto){
        const parsedBody: Partial<UserEntity> = {
            nickName: createOauthUserDto.firstName, 
            externalAuth: true,
            profileImage: createOauthUserDto.picture,
            email: createOauthUserDto.email,
            dateBirth: new Date(),
            firstName: createOauthUserDto.firstName,
            lastName: createOauthUserDto.lastName
        }

        const previous = await this.userRepository.findOneBy({email: createOauthUserDto.email, externalAuth: true})

        if (!previous) {
            const user = this.userRepository.create(parsedBody)
            const newUser = await this.userRepository.save(user)
            return {
                access_token: await this.jwtService.signAsync({
                    username: newUser.nickName, sub: newUser.id
                })
            }
        }
        
        return {access_token: await this.jwtService.signAsync({username: previous.nickName, sub: previous.id})}
    }

    async update(userId: string, UpdateUserDto: UpdateUserDto, req: any){
        const updateUser = await this.userRepository.preload({
            id: userId,
            ...UpdateUserDto
        })
        if(!updateUser){
            return 'There is no user with this characteristic';
        }
        if(req.file){
            const oldPhotoUrl = updateUser.profileImage;
            const oldPhotoId = oldPhotoUrl.split('/')[oldPhotoUrl.split('/').length-1];
            fs.unlink(join('uploads', 'img', oldPhotoId) , (err) => {
                if (err) {
                console.error(err);
                }else{
                    console.log(`${oldPhotoId} was deleted successfully`);
                }
            });
            const newImageUrl = `${req.protocol}://${req.get('host')}/img/${req.file.filename}`;
            const newUser = {
                ...updateUser,
                profileImage: newImageUrl
            }
            return await this.userRepository.save(newUser);
        } 
        return await this.userRepository.save(updateUser);
    }
    async delete(userId: string){
        const userUpdated = await this.userRepository.update({id: userId},
                                                             {status: false});
        if(!userUpdated){
            return 'There is not user with this characteristic';
        }
        return userUpdated;
    }
    
    findByName(firstName: string) {
        return this.userRepository.findOne({ where: { firstName } });
    }
    
    findByLastName(lastName: string) {
        return  this.userRepository.findOne({ where: { lastName } });
    }

    findByNickName(nickName: string) {
        return  this.userRepository.find({ where: { nickName } });
    }

    findByExactMatch(firstName: string, lastName: string){
        return this.userRepository.find({ where: { firstName: firstName, lastName: lastName } });
    }
}


