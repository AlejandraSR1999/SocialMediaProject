import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { DataBasesEnum } from '../../enums/data-bases.enum';
import { GroupEntity } from '../../persistence/group.entity';
import { Repository } from 'typeorm';
import { GroupsService } from './groups.service';

describe('GroupsService', () => {
  let service: GroupsService;
  let groupRepository: Repository<GroupEntity>;
  const GROUP_REPOSITORY_TOKEN = getRepositoryToken(GroupEntity, DataBasesEnum.POSTGRES);

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
      {
        provide: GroupsService,
        useValue: {
            create: jest.fn(),
            findByName: jest.fn()
        }
      },
      {
        provide: GROUP_REPOSITORY_TOKEN,
        useValue: {
            create: jest.fn(),
            delete: jest.fn(),
            update: jest.fn(),
            findOne: jest.fn()
        }
      }
    ],
    }).compile();

    service = module.get<GroupsService>(GroupsService);
    groupRepository = module.get<Repository<GroupEntity>>(GROUP_REPOSITORY_TOKEN);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call employeeRepository.create with the correct params',async()=>{
    await service.create({
      'group_name': 'groupName',
      'city': 'Santa Cruz',
      'detail': 'This group is amazing',
    }, '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed');
    expect(await service.create).toHaveBeenCalledWith({
       'group_name': 'groupName',
       'city': 'Santa Cruz',
       'detail': 'This group is amazing'
    }, '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed');
  });

  it('It should delete a group', async () => {
    const deleteGroup = jest.spyOn(groupRepository, 'delete');
    const groupId= '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed';
    groupRepository.delete(groupId);
    expect(deleteGroup).toHaveBeenCalledWith(groupId);

  });

  it('It should update a group', async () => {
    const updateGroup = jest.spyOn(groupRepository, 'update');
    const groupId = '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed';
    const groupExample = new GroupEntity();
    groupRepository.update(groupId, groupExample);
    expect(updateGroup).toHaveBeenCalledWith(groupId, groupExample);
  });

  it('It should findOne group', async () => {
    const findOneGroup = jest.spyOn(groupRepository, 'findOne');
    const idGroup = {};
    groupRepository.findOne(idGroup);
    expect(findOneGroup).toHaveBeenCalledWith(idGroup);
  });
});
