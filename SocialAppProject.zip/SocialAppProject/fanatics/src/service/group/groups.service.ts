import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataBasesEnum } from '../../enums/data-bases.enum';
import { Repository } from 'typeorm';
import { CreateGroupDto } from '../../dto/group.dto';
import { GroupEntity } from '../../persistence/group.entity';
import { UserGroupService } from '../user-group/user-group/user-group.service';
import { IUserService } from 'src/interfaces/IUserInterface.interface';

@Injectable()
export class GroupsService implements IUserService{

  constructor(
    @InjectRepository(GroupEntity, DataBasesEnum.POSTGRES)
    private readonly groupRepository: Repository<GroupEntity>,
    private readonly UserGroupService: UserGroupService
  ) {}

  async create(createGroupDto: CreateGroupDto, userId: string) {
    const newGroup = this.groupRepository.create(createGroupDto);
    const savingGroup = this.groupRepository.save(newGroup);
    const creatingRelation = this.UserGroupService.create(userId, await savingGroup);
    return savingGroup;
  }

  async findAll(): Promise<GroupEntity[]> {
    return await this.groupRepository.findBy({state:true});
  }

  async findOne(groupId: string) {
    const groupLocated = await this.groupRepository.findOneBy({id: groupId, state: true});
    if(!groupLocated){
      return 'There is not one any group with this characteristic';
    }
    return groupLocated;
  }
  findByName(name: string) {
    return this.groupRepository.findOne({ where: { group_name: name } });
  }

  async update(idGroup: string, groupToUpdate: CreateGroupDto){
    const groupFound = await this.groupRepository.findOneBy({id: idGroup});
    if(!groupFound){
      return 'There is not group with this characteristic';
    }
    const groupUpdated = await this.groupRepository.preload({
      id: idGroup,
      ...groupFound
    });
    return await groupUpdated;
  }

  async delete(idGroup: string){
    const groupUpdated = await this.groupRepository
      .update({ id: idGroup }, { state: false });

    if(!groupUpdated){
      return 'There is not group with this characteristic';
    }
    
    return groupUpdated;
  }
}
