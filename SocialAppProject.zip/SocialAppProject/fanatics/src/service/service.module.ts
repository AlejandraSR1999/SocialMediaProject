import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataBasesEnum } from '../enums/data-bases.enum';
import { GroupEntity } from '../persistence/group.entity';
import { UserEntity } from '../persistence/user.entity';
import { GroupsService } from './group/groups.service';
import { UserService } from './user/user.service';
import { UserGroupService } from './user-group/user-group/user-group.service';
import { UserGroupEntity } from '../persistence/user-group.entity';
import { InterestService } from './interest/interest.service';
import { InterestEntity } from '../persistence/interest.entity';
import { AuthModule } from 'src/auth/auth.module';


@Module({
    imports: [
        TypeOrmModule.forFeature([
          GroupEntity,
          UserEntity,
          UserGroupEntity,
          InterestEntity
        ], DataBasesEnum.POSTGRES),
        AuthModule
    ],
    providers: [
        GroupsService,
        UserService,
        UserGroupService,
        InterestService
    ],
    exports: [
        GroupsService,
        UserService,
        UserGroupService,
        InterestService
    ]
})

export class ServiceModule {}
