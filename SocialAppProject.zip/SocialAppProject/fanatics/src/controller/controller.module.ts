import { Module } from '@nestjs/common';
import { GroupsController } from './group/groups.controller';
import { ServiceModule } from '../service/service.module';
import { UserController } from './user/user.controller';
import { InterestController } from './interest/interest.controller';
import { MulterModule } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { v4 as uuidv4 } from 'uuid';
import { extname } from 'path';

@Module({
    imports: [
        ServiceModule,
        MulterModule.register({
            storage: diskStorage({
              destination: './uploads/img',
              filename: (req, file, cb) => {
                const newImageId = uuidv4();
                const fileName = `img-${newImageId}${extname(file.originalname)}`;
                cb(null, `${fileName}`);
              },
            }),
          }), 
    ],
    controllers: [
        GroupsController,
        UserController,
        InterestController
    ]
})
export class ControllerModule {}
