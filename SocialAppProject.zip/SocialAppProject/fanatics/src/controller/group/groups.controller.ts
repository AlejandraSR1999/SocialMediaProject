import { Controller, Get, Post, Body, Patch, Param, Delete, ParseUUIDPipe } from '@nestjs/common';
import { GroupsService } from '../../service/group/groups.service'
import { CreateGroupDto } from '../../dto/group.dto';
import { ApiNotFoundResponse, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { GroupEntity } from '../../persistence/group.entity';

@ApiTags('groups')
@Controller('groups')
export class GroupsController {
  constructor(private readonly groupsService: GroupsService) {}

  @Post('/userId/:id')
  @ApiOperation({ summary: 'Create group.' })
    @ApiResponse({ status: 201,
      description: 'Group was created.',
      type: GroupEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any group were found.' 
    })
  create(@Body() createGroupDto: CreateGroupDto, @Param('id', ParseUUIDPipe) userId: string) {
    return this.groupsService.create(createGroupDto, userId);
  }

  @Get()
  @ApiOperation({ summary: 'Get group data.' })
    @ApiResponse({ status: 200,
      description: 'group request succeeded.',
      type: GroupEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any group were found.' 
    })
  findAll() {
    return this.groupsService.findAll();
  }

  @Get('/groupId/:id')
  @ApiOperation({ summary: 'Get group data.' })
    @ApiResponse({ status: 200,
      description: 'Group request succeeded.',
      type: GroupEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any group were found.' 
    })
  findOne(@Param('id') id: string) {
    return this.groupsService.findOne(id);
  }
  
  @Delete('/groupId/:id')
  @ApiOperation({ summary: 'Delete Group by ID.' })
    @ApiResponse({ status: 200,
      description: 'Group deleted.',
      type: GroupEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'There is no group with this ID.' 
    })
  delete(@Param('id') groupId: string){
    return this.groupsService.delete(groupId);
  }
}
