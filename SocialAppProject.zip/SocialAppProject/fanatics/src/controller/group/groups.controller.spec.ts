import { Test, TestingModule } from '@nestjs/testing';
import { GroupEntity } from 'src/persistence/group.entity';
import { UserGroupService } from 'src/service/user-group/user-group/user-group.service';
import { Repository } from 'typeorm';
import { GroupsService } from '../../service/group/groups.service';
import { GroupsController } from './groups.controller';

describe('GroupsController', () => {
  let controller: GroupsController;
  let service: GroupsService;
  let groupRepository: Repository<GroupEntity>;
  let userGroupService: UserGroupService;

  beforeEach(async () => {
     const module: TestingModule = await Test.createTestingModule({
       controllers: [GroupsController],
       providers: [{
          provide: GroupsService,
          useValue: {
            findAll: jest.fn(),
            findOne: jest.fn(),
            delete: jest.fn()
          }
       }]
     }).compile();

    controller = module.get<GroupsController>(GroupsController);
    service = new GroupsService(groupRepository, userGroupService);

  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('findAll', () => {
    it('should be defined', async () => {
      const result = controller.findAll();
      jest.spyOn(service, 'findAll').mockImplementation(async() => result);
      expect(await controller.findAll()).toBe(result);
    });
  });
  
  describe('findOne', () => {
    it('should be defined', async () => {
      const result = controller.findOne('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed');
      jest.spyOn(service, 'findOne').mockImplementation(async() => result);
      expect(await controller.findOne('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed')).toBe(result);
    });
  });
  
  describe('delete', () => {
    it('should be defined', async () => {
      const result = controller.delete('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed');
      jest.spyOn(service, 'delete').mockImplementation(async() => result);
      expect(await service.delete('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed')).toBe(result);
    });
  });
  

});
