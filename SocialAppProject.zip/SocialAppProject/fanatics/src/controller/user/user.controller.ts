import { Body, Controller, Delete, Get, Req, UploadedFile, Param, Patch, Post, Query, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { CreateUserDto } from '../../dto/create-user.dto';
import { UserService } from '../../service/user/user.service';
import { UpdateUserDto } from '../../dto/update-user.dto';
import { CreateOauthUserDto } from '../../dto/create-oauth-user.dto';
import { ApiNotFoundResponse, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { UserEntity } from '../../persistence/user.entity';

@ApiTags('users')
@Controller('users')
export class UserController {
    constructor(
        private readonly userService: UserService
    ){}
    @Get()
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findAll() {
        return this.userService.findAll();
    }

    @Post()
    @ApiOperation({ summary: 'Create User.' })
    @ApiResponse({ status: 201,
      description: 'User was created.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    @UseInterceptors(FileInterceptor('file'))
    create(@Body() CreateUserDto: CreateUserDto, @Req() req: any){
        return this.userService.create(CreateUserDto, req);
    }

    @Post("/oauth")
    createOauthUser(@Body() oauthBody: CreateOauthUserDto) {
      return this.userService.createOauthUser(oauthBody)
    }

    @Patch('/userId/:id')
    @ApiOperation({ summary: 'Update user by ID.' })
    @ApiResponse({ status: 200,
      description: 'User updated.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'There is no user with this ID.' 
    })
    @UseInterceptors(FileInterceptor('file'))
    update(@Param('id') userId: string, @Body() UpdateUserDto: UpdateUserDto, @Req() req: any){
        return this.userService.update(userId, UpdateUserDto, req);
    }

    @Delete('/userId/:id')
    @ApiOperation({ summary: 'Delete user by ID.' })
    @ApiResponse({ status: 200,
      description: 'User deleted.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'There is no user with this ID.' 
    })
    delete(@Param('id') userId: string){
        return this.userService.delete(userId);
    }

    @Get('/searchUserId/:id')
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findById(@Param('id') userId: string) {
      return this.userService.findById(userId);
    }

    @Get('/searchfirstName/:firstName')
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findByFirstName(@Param('firstName') firstName: string){
        return this.userService.findByName(firstName);
    }

    @Get('/searchlastName/:lastName')
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findByLastName(@Param('lastName') lastName: string){
      return this.userService.findByLastName(lastName);
    }

    @Get('/searchnickName/:nickName')
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findByNickName(@Param('nickName') nickName: string){
      return this.userService.findByNickName(nickName);
    }

    @Get('fullName')
    @ApiOperation({ summary: 'Get user data.' })
    @ApiResponse({ status: 200,
      description: 'User request succeeded.',
      type: UserEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any user were found.' 
    })
    findByExactMatch(@Query('firstName') firstName: string, @Query('lastName') lastName: string){
      return this.userService.findByExactMatch(firstName, lastName);
    }


}
