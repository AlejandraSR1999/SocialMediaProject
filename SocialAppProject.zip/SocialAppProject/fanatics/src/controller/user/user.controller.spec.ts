import { Test, TestingModule } from '@nestjs/testing';
import { UserService } from '../../service/user/user.service';
import { UserController } from '../../controller/user/user.controller';
import { Repository } from 'typeorm';
import { UserEntity } from 'src/persistence/user.entity';
import { CreateUserDto } from 'src/dto/create-user.dto';

describe('UserController', () => {
  let controller: UserController;
  let service: UserService;
  
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserController],
      providers: [
        {
          provide: UserService,
          useValue: {
            findAll: jest.fn().mockReturnValue([{ id: 1, firstName: 'Alejandra', lastName: 'Salazar' }]),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn().mockResolvedValue('The user was deleted successfully'),
            findById: jest.fn(),
            findByExactMatch: jest.fn(),
          },
        },
      ],
    }).compile();
    controller = module.get<UserController>(UserController);
    service = module.get<UserService>(UserService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

describe('findAll', () => {
  it('should return an array of users', () => {
    const result = controller.findAll();
    expect(service.findAll).toHaveBeenCalled();
    expect(result).toEqual([{ id: 1, firstName: 'Alejandra', lastName: 'Salazar' }]);
    });
  });
  
  describe('findOne', () => {
    it('should return id', async () => {
      const result = controller.findById('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed');
      jest.spyOn(service, 'findById').mockImplementation(async() => result);
      expect(await controller.findById('1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed')).toBe(result);
    });
  });

  describe('createUser', () => {
    it('should create a user', async () => {
      const date = new Date("1999-01-01");
      const result = { id: 1, firstName: 'Alejandra', lastName: 'Salazar', dateBirth: date, nickName: 'ale',password: 'ale123',email: 'alexxa@gmail.com'};
      (service.create as jest.Mock).mockResolvedValue(result);
      
      const user = { firstName: 'Alejandra', lastName: 'Salazar', dateBirth: date, nickName: 'ale',password: 'ale123',email: 'alexxa@gmail.com'};
      expect(await controller.create(user)).toBe(result);
      expect(service.create).toHaveBeenCalledWith(user);
    });
  });

  describe('updateUser', () => {
    it('should update a user', async () => {
      const date = new Date("2008-09-01");
      const result = { id: '1', firstName: 'Emanuel', lastName: 'Herbas', dateBirth: date, nickName: 'ema',password: 'ema123',email: 'ema@gmail.com'};
      (service.update as jest.Mock).mockResolvedValue(result);

      expect(await controller.update('1', { firstName: 'Emanuel', lastName: 'Herbas', dateBirth: date, nickName: 'ema',password: 'ema123',email: 'ema@gmail.com'})).toBe(result);
    });
  });

  describe('deleteUser', () => {
    it('should delete a user', async () => {
      expect(await controller.delete('1')).toBe('The user was deleted successfully');
    });
  });

  describe('findByExactMatch', () => {
    it('should return the user with the exact first name and last name', async () => {
      const result = [{ id: 1, firstName: 'Alejandra', lastName: 'Salazar' }];
      (service.findByExactMatch as jest.Mock).mockResolvedValue(result);
  
      expect(await controller.findByExactMatch('Alejandra', 'Salazar')).toBe(result);
    });
  });  
});
