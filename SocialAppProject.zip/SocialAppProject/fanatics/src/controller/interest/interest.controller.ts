import { Controller, Body, Delete, Get, Param, Patch, Post, Put } from '@nestjs/common';
import { InterestService } from '../../service/interest/interest.service';
import { InterestDTO } from '../../dto/interest.dto'
import { ApiNotFoundResponse, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { InterestEntity } from '../../persistence/interest.entity';

@ApiTags('interest')
@Controller('interest')
export class InterestController {
    constructor(
        private readonly interestService: InterestService
    ){}

    @Get()
    @ApiOperation({ summary: 'Get interest data.' })
    @ApiResponse({ status: 200,
      description: 'Interest request succeeded.',
      type: InterestEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any interest were found.' 
    })
    findAll() {
        return this.interestService.findAll();
    }

    @Post()
    @ApiOperation({ summary: 'Create interest.' })
    @ApiResponse({ status: 201,
      description: 'Interest was created.',
      type: InterestEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any interest were found.' 
    })
    create(@Body() InterestDTO: InterestDTO){
        return this.interestService.create(InterestDTO);
    }

    @Get('/interestId/:id')
    @ApiOperation({ summary: 'Get interest data.' })
    @ApiResponse({ status: 200,
      description: 'Interest request succeeded.',
      type: InterestEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'Any interest were found.' 
    })
    findOne(@Param('id') idInteres: number) {
      return this.interestService.findOne(idInteres);
    }

    @Patch('/interestId/:id')
    @ApiOperation({ summary: 'Update interest by ID.' })
    @ApiResponse({ status: 200,
      description: 'Interest updated.',
      type: InterestEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'There is no interest with this ID.' 
    })
    update(@Param('id') interestId: number, @Body() UpdateUserDto: InterestDTO){
        return this.interestService.update(interestId, UpdateUserDto);
    }

    @Delete('/interestId/:id')
    @ApiOperation({ summary: 'Delete interest by ID.' })
    @ApiResponse({ status: 200,
      description: 'Interest deleted.',
      type: InterestEntity
    })
    @ApiResponse({ status: 400,
      description: 'Bad request.' 
    })
    @ApiNotFoundResponse({ status: 404,
      description: 'There is no interest with this ID.' 
    })
    delete(@Param('id') interestId: number){
        return this.interestService.delete(interestId);
    }
}
