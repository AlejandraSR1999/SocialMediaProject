import { Test, TestingModule } from '@nestjs/testing';
import { STATUS_CODES } from 'http';
import { EMPTY, find } from 'rxjs';
import { InterestService } from '../../service/interest/interest.service';
import { InterestController } from './interest.controller';

describe('InterestController - Positive tests', () => {
  let controller: InterestController;

  const mockInterestService = {
    create: jest.fn(dto => {
      return {
        id_interest: 1,
        ...dto
      }
    }),

    findAll: jest.fn(dto => {
      return [{
          id_interest: 1,
          user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
          interest: "Pruebita"
        
      }]
    }),

    findOne: jest.fn(dto => {
      return {
        id_interest: dto,
        user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
        interest: "Prueba de Nombre de Interes"
      }
    }),

    update: jest.fn(dto => {
      return {
        id_interest: dto,
        user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
        interest: "Prueba de Nombre de Interes"
      }
    }),

    delete: jest.fn(dto => {
      return EMPTY;
    })
  }

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [InterestController],
      providers: [InterestService]
    })
    .overrideProvider(InterestService)
    .useValue(mockInterestService)
    .compile();

    controller = module.get<InterestController>(InterestController);
  });


  it('should be created', () => { 
    expect(controller.create({
      user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
      interest: "Prueba de Nombre de Interes"
    })).toEqual({
      user_id: expect.any(String),
      interest: expect.any(String),
      id_interest: expect.any(Number)
    })
  
  });


  it('should bring all data', () => {
    expect(controller.findAll()).toEqual(expect.any(Array))
  });


  it('should bring one specific interest', () => {
    expect(controller.findOne(1)).toEqual({
      id_interest: expect.any(Number),
      user_id: expect.any(String),
      interest: expect.any(String),
    })
  });


  it('should update an specific interest', () => {
    expect(controller.update(1, {
                                  user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
                                  interest: "Nombre de interes cambiado"
    }))
    .toEqual({
      id_interest: expect.any(Number),
      user_id: expect.any(String),
      interest: expect.any(String),
    })
  });


  it('should delete an specific interest', () => {
    expect(controller.delete(1)).toEqual(EMPTY)
  });

});



describe('InterestController - Negative tests', () => {
  let controller: InterestController;

  const mockInterestService = {
    create: jest.fn(dto => {
      return {
        statusCode: 400,
        message: [
            "Please provide a user id.",
            "User id must be a string.",
            "Please provide a interest.",
            "Interest must be a string.",
            "The Interest name must be uppercase, lowercase or spaces"
        ],
        error: "Bad Request"
      }
    }),

    findOne: jest.fn(dto => {
      return EMPTY
    }),

    update: jest.fn(dto => {
      return 'There is no interest with this characteristic';
    }),

    delete: jest.fn(dto => {
      return EMPTY;
    })

  }

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [InterestController],
      providers: [InterestService]
    })
    .overrideProvider(InterestService)
    .useValue(mockInterestService)
    .compile();

    controller = module.get<InterestController>(InterestController);
  });


  it('should receive a error response (POST bad request)', () => { 
    expect(controller.create(null)).toEqual({
      statusCode: expect.any(Number),
      message: expect.any(Array),
      error: expect.any(String)
    })  
  });


  it('should receive a error response (GET bad request)', () => { 
    expect(controller.findOne(null)).toEqual(EMPTY)
  });


  it('should receive a error response (PATCH bad request)', () => { 
    expect(controller.update(null, {user_id: "75edecfe-c0b8-495f-8a49-01d5bc1dff45",
                                    interest: "Prueba de cambio de interés"  
    }))
    .toEqual("There is no interest with this characteristic")
  });


  it('should receive a error response (DELETE bad request)', () => { 
    expect(controller.delete(null)).toEqual(EMPTY)
  });
});