import { Body, Controller, Get, Post, Req, Request, Res, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginUserDTO } from '../dto/login-user.dto';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}
  
  @Post("/login")
  login(@Body() loginBody: LoginUserDTO) {
    return this.authService.login(loginBody);
  }
 
  @UseGuards(JwtAuthGuard)
  @Get('/me')
  async getClientUser(@Request() req) {
    return this.authService.getClientUser(req.user.userId)
  }
}










