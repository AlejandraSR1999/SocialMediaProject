import { Injectable, Inject, UnauthorizedException } from '@nestjs/common';
import { UserEntity } from '../persistence/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { DataBasesEnum } from '../enums/data-bases.enum';
import { LoginUserDTO } from '../dto/login-user.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(UserEntity,DataBasesEnum.POSTGRES) private readonly userRepository: Repository<UserEntity>,
    private jwtService: JwtService
  ) {}

  async validateUser(username: string, password: string){
    const user = await this.userRepository.findOneBy({nickName:username, externalAuth: false});
    if (user && user.password === password) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  async getClientUser(id: string) {
   const {firstName, lastName, nickName, email, dateBirth, profileImage } = await this.userRepository.findOneBy({ id });
   return {
    firstName,
    lastName,
    nickName,
    email,
    dateBirth,
    profileImage
   }
  }

  async login(loginUserDTO:LoginUserDTO) {
    const user = await this.userRepository.findOneBy({nickName:loginUserDTO.username, externalAuth: false});
    if (user?.password !== loginUserDTO.password) {
      throw new UnauthorizedException();
    }
    const payload = { username: user.nickName, sub: user.id };
    return {
      access_token: await this.jwtService.signAsync(payload),
    };
  }
}






