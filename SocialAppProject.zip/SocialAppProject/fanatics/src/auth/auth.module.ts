import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { PassportModule } from '@nestjs/passport';
import { LocalStrategy } from '../strategies/local.strategy';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../persistence/user.entity';
import { DataBasesEnum } from '../enums/data-bases.enum';
import { JwtModule } from '@nestjs/jwt';
import { AppModule } from 'src/app.module';
import { JwtStrategy } from 'src/strategies/jwt.strategy';

@Module({
  imports: [
    PassportModule,
        JwtModule.register({
      secret: 'socialsecurity',
      signOptions: {
        expiresIn: '3600s'
      }
    }),
    TypeOrmModule.forFeature([UserEntity],DataBasesEnum.POSTGRES),
    ClientsModule.register([
      {
        name: 'AUTH_SERVICE',
        transport: Transport.TCP,
        options: {
          host: '127.0.0.1',
          port: 8877,
        },
      },
    ]),
  ],
  providers: [AuthService,LocalStrategy, JwtStrategy],
  exports: [JwtModule, JwtStrategy],
  controllers: [AuthController],
})
export class AuthModule {}
