export interface IUserService {
  findById?(userId: string);
  findByName?(firstName: string);
  findByLastName?(lastName: string);
  findByNickName?(nickName: string);
  findByExactMatch?(firstName: string,lastName: string);
}
