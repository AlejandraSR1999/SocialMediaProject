import { MigrationInterface, QueryRunner } from "typeorm"

export class modifier1676291041432 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "interest" ADD COLUMN "description" int`,
        )
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
            `ALTER TABLE "post" DELETE COLUMN "description"`,
        )
    }

}
