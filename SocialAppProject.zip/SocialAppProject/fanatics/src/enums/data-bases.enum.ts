export enum DataBasesEnum {
  POSTGRES = 'postgres',
}
