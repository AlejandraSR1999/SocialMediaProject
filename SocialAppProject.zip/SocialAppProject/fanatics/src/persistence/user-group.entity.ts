import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Privilege } from '../enums/privilege.enum';
import { GroupEntity } from './group.entity';
import { UserEntity } from './user.entity';

@Entity('user-group')
export class UserGroupEntity {
  @ApiProperty({
    description: 'number',
    example: '1',
    uniqueItems: true,
    type: String
  })
  @PrimaryGeneratedColumn('increment', { name: 'id_registration' })
  id: string;
  @ManyToOne(() => GroupEntity, (GroupEntity) => GroupEntity.id)
  group_: string;
  @ManyToOne(() => UserEntity, (UserEntity) => UserEntity.id)
  user_: string;
  @Column({
    name: 'join_date',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  joinDate: Date;
  @Column({
    name: 'privilege',
    type: 'enum',
    enum: Privilege,
    default: Privilege.SUPER_ADMIN,
  })
  privilege: Privilege;
}
