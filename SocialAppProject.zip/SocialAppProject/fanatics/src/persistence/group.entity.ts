import { Field, ObjectType } from '@nestjs/graphql';
import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@ObjectType()
@Entity('group')
export class GroupEntity {
    @ApiProperty({
      description: 'UUID',
      example: '724949a9-81c7-424d-abc8-73f170d6ca21',
      uniqueItems: true,
      type: String
    })
    @Field({ nullable: false })
    @PrimaryGeneratedColumn('uuid', { name: 'group_id' })
    id: string;

    @ApiProperty({
      description: 'varchar',
      example: 'Liga X',
      uniqueItems: true,
      type: String
    })
    @Field({ nullable: false })
    @Column({ name: 'group_name', type: 'varchar', length: 60 })
    group_name: string;

    @ApiProperty({
      description: 'varchar',
      example: 'Santa Cruz',
      uniqueItems: true,
      type: String
    })
    @Field({ nullable: false })
    @Column({ name: 'city', type: 'varchar', length: 60 })
    city: string;

    @ApiProperty({
      description: 'varchar',
      example: 'This is my group',
      uniqueItems: true,
      type: String
    })
    @Field({ nullable: false })
    @Column({ name: 'detail', type: 'varchar', length: 120})
    detail: string;

    @ApiProperty({
      description: 'boolean',
      example: 'false',
      uniqueItems: true,
      type: Boolean
    })
    @Field({ nullable: false })
    @Column({ name: 'state', type: 'boolean', default: true})
    state: boolean;
}
