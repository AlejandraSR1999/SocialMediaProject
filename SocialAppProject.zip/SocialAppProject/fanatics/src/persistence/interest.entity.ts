import { Field, ObjectType } from '@nestjs/graphql';
import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserEntity } from './user.entity';

@ObjectType()
@Entity('interest')
export class InterestEntity {
  @ApiProperty({
    description: 'number',
    example: '1',
    uniqueItems: true,
    type: Number
  })
  @Field({ nullable: false })
  @PrimaryGeneratedColumn('increment', { name: 'interest_id' })
  id_interest: number;

  @ApiProperty({
    description: 'UUID',
    example: '724949a9-81c7-424d-abc8-73f170d6ca21',
    uniqueItems: true,
    type: String
  })
  @Field({ nullable: false })
  @Column({ name: 'user_id', type: 'uuid'})
  user_id: string;
 
  @ApiProperty({
    description: 'varchar',
    example: 'wally',
    uniqueItems: true,
    type: String
  })
  @Field({ nullable: false })
  @Column({ name: 'interest', type: 'varchar', length: 90 })
  interest: string;
  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user: UserEntity;
}
