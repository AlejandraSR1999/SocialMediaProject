import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { InterestEntity } from './interest.entity';
import { Field, ObjectType } from '@nestjs/graphql';


@ObjectType()
@Entity('user')
export class UserEntity {
  @ApiProperty({
    description: 'UUID',
    example: '724949a9-81c7-424d-abc8-73f170d6ca21',
    uniqueItems: true,
    type: String
  })
  @PrimaryGeneratedColumn('uuid', { name: 'user_id' })
  @Field({ nullable: false })
  id: string;

  @ApiProperty({
    description: 'varchar',
    example: 'Marcos',
    uniqueItems: true,
    type: String
  })
  @Column({ name: 'first_name', type: 'varchar', length: 90 })
  @Field({ nullable: false })
  firstName: string;

  @ApiProperty({
    description: 'varchar',
    example: 'Pain',
    uniqueItems: true,
    type: String
  })
  @Column({ name: 'last_name', type: 'varchar', length: 90 })
  @Field({ nullable: false })
  lastName: string;

  @ApiProperty({
    description: 'date',
    example: '1990-01-01',
    uniqueItems: true,
    type: Date
  })
  @Column({ name: 'date_birth', type: 'date' })
  @Field({ nullable: false })
  dateBirth: Date;
  
  @ApiProperty({
    description: 'varchar',
    example: 'emager18',
    uniqueItems: true,
    type: String
  })
  @Column({ name: 'nick_name', type: 'varchar', length: 50 })
  @Field({ nullable: false })
  nickName: string;

  @ApiProperty({
    description: 'varchar',
    example: '123calabazin',
    uniqueItems: true,
    type: String
  })
  @Column({ name: 'password', type: 'varchar', length: 200, nullable: true })
  @Field({ nullable: true})
  password: string;

  @ApiProperty({
    description: 'varchar',
    example: 'marcos@gmail.com',
    uniqueItems: true,
    type: String
  })
  @Column({ name: 'email', type: 'varchar', length: 100 })
  @Field({ nullable: false })
  email: string;

  @ApiProperty({
    description: 'boolean',
    example: 'false',
    uniqueItems: true,
    type: Boolean
  })
  @Column({ name: 'status', type: 'boolean', default: true})
  @Field({ nullable: true })
  status: boolean;

  @Field(type => [InterestEntity],{ nullable: true }) 
  @OneToMany(() => InterestEntity, interests => interests.user, { eager: true })
  interests: InterestEntity[];
  @Column({ name: 'profileImage', type: 'varchar', length: 255, default: null})
  profileImage: string;

  @Field()
  @Column({ name: 'external_auth', type: 'boolean', default: false})
  externalAuth: boolean
}
