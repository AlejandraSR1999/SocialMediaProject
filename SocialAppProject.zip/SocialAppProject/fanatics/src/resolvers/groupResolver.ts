import { Args, Query, Resolver } from '@nestjs/graphql';
import { GroupEntity } from 'src/persistence/group.entity';
import { GroupsService } from 'src/service/group/groups.service';

@Resolver(of => GroupEntity)
export class GroupResolver {
  constructor(
    private readonly groupService: GroupsService
  ) { }

  @Query(returns => [GroupEntity], { name: 'groups', nullable: false })
  async getGroups() {
    return this.groupService.findAll();
  }

  @Query(returns => GroupEntity, { name: 'group', nullable: true })
  async getGroupById(
    @Args({ name: 'name', type: () => String }) name: string
  ){
    return this.groupService.findByName(name);
  }

}