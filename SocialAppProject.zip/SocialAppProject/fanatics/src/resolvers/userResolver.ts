import { Args, Query, Resolver } from '@nestjs/graphql';
import { UserEntity} from '../persistence/user.entity';
import { UserService } from '../service/user/user.service';
import { InterestService } from '../service/interest/interest.service';
import { forwardRef, Inject, Req } from '@nestjs/common';
import { CreateUserDto } from '../dto/create-user.dto';

@Resolver(of => UserEntity)
export class UserResolver {
  constructor(
    private readonly userService: UserService,
    @Inject(forwardRef(() => InterestService))
    private readonly interestService: InterestService,
  ) { }

  @Query(returns => [UserEntity], { name: 'users', nullable: false })
  async getUsers() {
    return this.userService.findAll();
  }

  @Query(returns => UserEntity, { name: 'user', nullable: true })
  async getUserById(
    @Args({ name: 'id', type: () => String }) id: string
  ){
    return this.userService.findById(id);
  }

}