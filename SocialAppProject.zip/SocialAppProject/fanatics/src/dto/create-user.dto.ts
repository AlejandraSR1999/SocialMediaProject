import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEmail, IsNotEmpty, IsString, Matches } from 'class-validator';
import { InterestEntity } from '../persistence/interest.entity';

export class CreateUserDto {
  @IsNotEmpty({ message: 'Please provide a first name.' })
  @Matches(/[a-zA-Z ]$/, {
    message: 'The First name must be uppercase, lowercase or spaces',
  })
  @ApiProperty({
    description: 'The first name of a person'
  })
  firstName: string;

  @IsNotEmpty({ message: 'Please provide a last name.' })
  @Matches(/[a-zA-Z ]$/, {
    message: 'The last name must be uppercase, lowercase or spaces',
  })
  @ApiProperty({
    description: 'The last name of a person'
  })
  lastName: string;

  @IsNotEmpty({ message: 'Please provide a dateBirth.' })
  @IsDateString()
  @ApiProperty({
    description: 'The date birth of a person'
  })
  dateBirth: Date;

  @IsNotEmpty({ message: 'Please provide a nickname.' })
  @IsString({ message: 'nick name must be a string.' })
  @Matches(/[a-zA-Z0-9 .@*-_]$/, {
    message: 'The nickname doesnt meet the requirements',
  })
  @ApiProperty({
    description: 'The nick name of a person'
  })
  nickName: string;

  @IsNotEmpty({ message: 'Please provide a password.' })
  @IsString({ message: 'password must be a string.' })
  @Matches(/[a-zA-Z0-9 .@*-_]$/, {
    message: 'The password doesnt meet the requirements',
  })
  @ApiProperty({
    description: 'The password of a person'
  })
  password: string;
  
  @IsNotEmpty({ message: 'Please provide an email.' })
  @IsEmail()
  @ApiProperty({
    description: 'The email of a person'
  })
  email: string;

  @ApiProperty({
    description: 'The status of a user'
  })
  status?: boolean;

  @ApiProperty({
    description: 'The interests of a person'
  })
  interests?: InterestEntity[];
  @ApiProperty({
    description: 'Profile url image'
  })
  profileImage: string;
}
