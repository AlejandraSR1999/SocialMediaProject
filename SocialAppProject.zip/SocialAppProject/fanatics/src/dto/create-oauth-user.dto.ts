
import { Field, InputType } from '@nestjs/graphql';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsDate, IsEmail, IsNotEmpty, IsString, Matches } from 'class-validator';
import { InterestEntity } from '../persistence/interest.entity';
import { InterestDTO } from './interest.dto';

@InputType()
export class CreateOauthUserDto {
  @Field()
  @IsNotEmpty({ message: 'Please provide a first name.' })
  @Matches(/[a-zA-Z ]$/, {
    message: 'The First name must be uppercase, lowercase or spaces',
  })
  @ApiProperty({
    description: 'The first name of a person'
  })
  firstName: string;

  @Field()
  @IsNotEmpty({ message: 'Please provide a last name.' })
  @Matches(/[a-zA-Z ]$/, {
    message: 'The last name must be uppercase, lowercase or spaces',
  })
  @ApiProperty({
    description: 'The last name of a person'
  })
  lastName: string;

  @Field()
  @Type(() => Date)
  @ApiProperty({
    description: 'The date birth of a person'
  })
  dateBirth: Date;

  @Field()
  @IsNotEmpty({ message: 'Please provide a nickname.' })
  @IsString({ message: 'nick name must be a string.' })
  @Matches(/[a-zA-Z0-9 .@*-_]$/, {
    message: 'The nickname doesnt meet the requirements',
  })
  @ApiProperty({
    description: 'The nick name of a person'
  })
  nickName: string;

  @Field()
  @IsNotEmpty({ message: 'Please provide an email.' })
  @IsEmail()
  @ApiProperty({
    description: 'The email of a person'
  })
  email: string;

  @ApiProperty({
    description: 'Profile url image'
  })
  picture: string;
}