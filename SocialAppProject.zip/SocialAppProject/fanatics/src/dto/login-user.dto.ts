import { Field, InputType } from '@nestjs/graphql';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, Matches } from 'class-validator';

@InputType()
export class LoginUserDTO {
  @Field()
  @IsString({ message: 'Username must be a string.' })
  @IsNotEmpty({ message: 'Please provide a username.' })
  @ApiProperty({
    description: 'Username property'
  })
  username: string;

  @Field()
  @IsString({ message: 'Password must be a string.' })
  @IsNotEmpty({ message: 'Please provide a password.' })
  @ApiProperty({
    description: 'Password property'
  })
  password: string;

}