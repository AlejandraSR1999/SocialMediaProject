import { Field, InputType } from '@nestjs/graphql';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, Matches } from 'class-validator';

export class InterestDTO {

  @IsString({ message: 'User id must be a string.' })
  @IsNotEmpty({ message: 'Please provide a user id.' })
  @ApiProperty({
    description: 'The id of user'
  })
  user_id: string;

  @Matches(/[a-zA-Z0-9 ]$/, {
    message: 'The Interest name must be uppercase, lowercase or spaces',
  })
  @IsString({ message: 'Interest must be a string.' })
  @IsNotEmpty({ message: 'Please provide a interest.' })
  @ApiProperty({
    description: 'The interest of a person'
  })
  interest: string;
}