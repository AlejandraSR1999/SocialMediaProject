import { Privilege } from 'src/enums/privilege.enum';

export class UserGroupDto {
  idUser: string;
  idGroup: string;
  joinDate?: Date;
  privilege?: Privilege;
}
