import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString, Min, IsBoolean } from 'class-validator';

export class CreateGroupDto {
  @IsString({ message: 'Group name must be a string.' })
  @IsNotEmpty({ message: 'Please provide a group name.' })
  @ApiProperty({
    description: 'The name of group'
  })
  group_name: string;
  @IsString({ message: 'City must be a string.' })
  @IsNotEmpty({ message: 'Please provide a city.' })
  @ApiProperty({
    description: 'The city of group'
  })
  city: string;
  @IsString({ message: 'Detail must be a string.' })
  @IsNotEmpty({ message: 'Please provide a detail' })
  @ApiProperty({
    description: 'The detail of group'
  })
  detail: string;
  @IsBoolean({ message: 'The state must be boolean.' })
  @IsNotEmpty({ message: 'Please provide the group state.' })
  @ApiProperty({
    description: 'The state of group'
  })
  state?: boolean;
}