import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataBasesEnum } from './enums/data-bases.enum';
import { ServiceModule } from './service/service.module';
import { ControllerModule } from './controller/controller.module';
import { AuthModule } from './auth/auth.module';
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriverConfig, ApolloDriver } from '@nestjs/apollo';
import { UserResolver } from './resolvers/userResolver';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { UserEntity } from './persistence/user.entity';
import { GroupEntity } from './persistence/group.entity';
import { InterestEntity } from './persistence/interest.entity';
import { UserGroupEntity } from './persistence/user-group.entity';
import { GroupResolver } from './resolvers/groupResolver';


@Module({
  imports: [
    ServiceModule,
    ControllerModule,
    TypeOrmModule.forRoot({
      name: DataBasesEnum.POSTGRES,
      type: DataBasesEnum.POSTGRES,
      host: process.env.DB_URL || 'localhost',
      port: 5432,
      username: process.env.DB_USER || 'root',
      password: process.env.DB_PASS || 'socialapp2023',
      database: process.env.DB_NAME || 'socialapp',
      entities: [UserEntity,GroupEntity,InterestEntity,UserGroupEntity],
      autoLoadEntities: true,
      synchronize: true
    }),   
    AuthModule,
    GraphQLModule.forRoot<ApolloDriverConfig>({ 
      driver: ApolloDriver,
      autoSchemaFile: true 
    }),
    // ServeStaticModule.forRoot({
    //   rootPath: join(__dirname, '..', '..', 'uploads'),
    // })  
  ],
  exports: [TypeOrmModule],
  providers: [UserResolver, GroupResolver],
})
export class AppModule {}
